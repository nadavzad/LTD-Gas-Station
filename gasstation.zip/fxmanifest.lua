fx_version 'cerulean'
game 'gta5'


files {
    'stream/gas.ymap'
}

lua54 'yes'
this_is_a_map "yes"